<?php
session_start();
require_once 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND role = ?");
    $stmt->execute([$email, $role]);
    $user = $stmt->fetch();

    if ($user && $user['password'] === MD5($password)) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        
        switch($role) {
            case 'admin':
                header('Location: admin/dashboard.php');
                break;
            case 'manager':
                header('Location: manager/dashboard.php');
                break;
            case 'member':
                header('Location: member/dashboard.php');
                break;
        }
        exit();
    } else {
        $error = "Geçersiz email veya şifre!";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sinema Otomasyonu - Giriş</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <h2 class="text-center mb-4">Sinema Otomasyonu</h2>
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Şifre</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Rol</label>
                    <select name="role" class="form-control" required>
                        <option value="member">Üye</option>
                        <option value="manager">Yönetici</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Giriş Yap</button>
            </form>

            <div class="mt-4 p-3 bg-light rounded">
                <h5 class="mb-3">Demo Giriş Bilgileri:</h5>
                
                <div class="mb-3">
                    <h6 class="text-primary">Admin Hesabı:</h6>
                    <div class="d-flex align-items-center mb-2">
                        <strong class="mr-2">Email:</strong>
                        <span id="adminEmail">shenzy@gmail.com</span>
                        <button class="btn btn-sm btn-outline-secondary ml-2" onclick="copyToClipboard('adminEmail')">Kopyala</button>
                    </div>
                    <div class="d-flex align-items-center">
                        <strong class="mr-2">Şifre:</strong>
                        <span id="adminPassword">shenzy</span>
                        <button class="btn btn-sm btn-outline-secondary ml-2" onclick="copyToClipboard('adminPassword')">Kopyala</button>
                    </div>
                </div>

                <div class="mb-3">
                    <h6 class="text-success">Yönetici Hesabı:</h6>
                    <div class="d-flex align-items-center mb-2">
                        <strong class="mr-2">Email:</strong>
                        <span id="managerEmail">medine@gmail.com</span>
                        <button class="btn btn-sm btn-outline-secondary ml-2" onclick="copyToClipboard('managerEmail')">Kopyala</button>
                    </div>
                    <div class="d-flex align-items-center">
                        <strong class="mr-2">Şifre:</strong>
                        <span id="managerPassword">medine</span>
                        <button class="btn btn-sm btn-outline-secondary ml-2" onclick="copyToClipboard('managerPassword')">Kopyala</button>
                    </div>
                </div>

                <div>
                    <h6 class="text-info">Üye Hesabı:</h6>
                    <div class="d-flex align-items-center mb-2">
                        <strong class="mr-2">Email:</strong>
                        <span id="memberEmail">helin@gmail.com</span>
                        <button class="btn btn-sm btn-outline-secondary ml-2" onclick="copyToClipboard('memberEmail')">Kopyala</button>
                    </div>
                    <div class="d-flex align-items-center">
                        <strong class="mr-2">Şifre:</strong>
                        <span id="memberPassword">helin</span>
                        <button class="btn btn-sm btn-outline-secondary ml-2" onclick="copyToClipboard('memberPassword')">Kopyala</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function copyToClipboard(elementId) {
            const element = document.getElementById(elementId);
            const text = element.textContent;
            navigator.clipboard.writeText(text).then(() => {
                alert('Kopyalandı!');
            }).catch(err => {
                console.error('Kopyalama başarısız:', err);
            });
        }
    </script>
</body>
</html> 