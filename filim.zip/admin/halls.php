<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Handle hall deletion
if (isset($_POST['delete_hall'])) {
    $hall_id = $_POST['hall_id'];
    $stmt = $db->prepare("DELETE FROM halls WHERE id = ?");
    $stmt->execute([$hall_id]);
    header('Location: halls.php');
    exit();
}

// Handle hall addition/editing
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_hall'])) {
    $name = $_POST['name'];
    $total_seats = $_POST['total_seats'];
    
    if (isset($_POST['hall_id'])) {
        // Update existing hall
        $stmt = $db->prepare("UPDATE halls SET name = ?, total_seats = ? WHERE id = ?");
        $stmt->execute([$name, $total_seats, $_POST['hall_id']]);
    } else {
        // Add new hall
        $stmt = $db->prepare("INSERT INTO halls (name, total_seats) VALUES (?, ?)");
        $stmt->execute([$name, $total_seats]);
        
        // Get the new hall ID
        $hall_id = $db->lastInsertId();
        
        // Create seats for the new hall
        $rows = ceil($total_seats / 10); // Assuming 10 seats per row
        $seats_per_row = ceil($total_seats / $rows);
        
        for ($row = 0; $row < $rows; $row++) {
            for ($seat = 1; $seat <= $seats_per_row; $seat++) {
                $seat_number = chr(65 + $row) . $seat; // A1, A2, B1, B2, etc.
                $stmt = $db->prepare("INSERT INTO seats (hall_id, seat_number) VALUES (?, ?)");
                $stmt->execute([$hall_id, $seat_number]);
            }
        }
    }
    
    header('Location: halls.php');
    exit();
}

// Get all halls with seat information
$halls = $db->query("
    SELECT h.*, 
           COUNT(s.id) as total_seats,
           SUM(CASE WHEN s.is_available = 1 THEN 1 ELSE 0 END) as available_seats
    FROM halls h
    LEFT JOIN seats s ON h.id = s.hall_id
    GROUP BY h.id
    ORDER BY h.name
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salon Yönetimi - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Admin Panel</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="movies.php">
                            <i class="fas fa-film"></i> Filmler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="halls.php">
                            <i class="fas fa-door-open"></i> Salonlar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="screenings.php">
                            <i class="fas fa-calendar-alt"></i> Seanslar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users"></i> Kullanıcılar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="payments.php">
                            <i class="fas fa-credit-card"></i> Ödemeler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletler
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Salon Yönetimi</h2>
                    <button class="btn btn-primary" data-toggle="modal" data-target="#hallModal">
                        <i class="fas fa-plus"></i> Yeni Salon Ekle
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Salon Adı</th>
                                <th>Toplam Koltuk</th>
                                <th>Müsait Koltuk</th>
                                <th>İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($halls as $hall): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($hall['name']); ?></td>
                                <td><?php echo $hall['total_seats']; ?></td>
                                <td><?php echo $hall['available_seats']; ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info edit-hall" 
                                            data-id="<?php echo $hall['id']; ?>"
                                            data-name="<?php echo htmlspecialchars($hall['name']); ?>"
                                            data-seats="<?php echo $hall['total_seats']; ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Bu salonu silmek istediğinizden emin misiniz?');">
                                        <input type="hidden" name="hall_id" value="<?php echo $hall['id']; ?>">
                                        <button type="submit" name="delete_hall" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Hall Modal -->
    <div class="modal fade" id="hallModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Salon Ekle/Düzenle</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="hall_id" id="hall_id">
                        <div class="form-group">
                            <label>Salon Adı</label>
                            <input type="text" name="name" id="name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Toplam Koltuk Sayısı</label>
                            <input type="number" name="total_seats" id="total_seats" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">İptal</button>
                        <button type="submit" name="save_hall" class="btn btn-primary">Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.edit-hall').click(function() {
                var id = $(this).data('id');
                var name = $(this).data('name');
                var seats = $(this).data('seats');
                
                $('#hall_id').val(id);
                $('#name').val(name);
                $('#total_seats').val(seats);
                
                $('#hallModal').modal('show');
            });
        });
    </script>
</body>
</html> 