<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Get all payments with related information
$stmt = $db->prepare("
    SELECT p.*, 
           t.id as ticket_id,
           u.name as user_name,
           u.email as user_email,
           m.title as movie_title,
           s.screening_time,
           h.name as hall_name,
           st.seat_number
    FROM payments p
    JOIN tickets t ON p.ticket_id = t.id
    JOIN users u ON t.user_id = u.id
    JOIN screenings s ON t.screening_id = s.id
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    JOIN seats st ON t.seat_id = st.id
    ORDER BY p.payment_date DESC
");
$stmt->execute();
$payments = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ödemeler - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Admin Paneli</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="movies.php">
                            <i class="fas fa-film"></i> Filmler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="halls.php">
                            <i class="fas fa-door-open"></i> Salonlar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="screenings.php">
                            <i class="fas fa-calendar-alt"></i> Seanslar
                        </a>
                    </li>
          
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users"></i> Kullanıcılar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="payments.php">
                            <i class="fas fa-credit-card"></i> Ödemeler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletler
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <h2 class="mb-4">Ödemeler</h2>

                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Ödeme ID</th>
                                        <th>Bilet ID</th>
                                        <th>Kullanıcı</th>
                                        <th>Film</th>
                                        <th>Seans</th>
                                        <th>Salon</th>
                                        <th>Koltuk</th>
                                        <th>Kart Bilgileri</th>
                                        <th>Tutar</th>
                                        <th>Ödeme Tarihi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($payments as $payment): ?>
                                    <tr>
                                        <td><?php echo $payment['id']; ?></td>
                                        <td><?php echo $payment['ticket_id']; ?></td>
                                        <td>
                                            <?php echo htmlspecialchars($payment['user_name']); ?><br>
                                            <small class="text-muted"><?php echo htmlspecialchars($payment['user_email']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($payment['movie_title']); ?></td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($payment['screening_time'])); ?></td>
                                        <td><?php echo htmlspecialchars($payment['hall_name']); ?></td>
                                        <td><?php echo $payment['seat_number']; ?></td>
                                        <td>
                                            <strong>Kart Sahibi:</strong> <?php echo htmlspecialchars($payment['card_holder']); ?><br>
                                            <strong>Kart No:</strong> <?php echo $payment['card_number']; ?>
                                        </td>
                                        <td><?php echo number_format($payment['amount'], 2); ?> TL</td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($payment['payment_date'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 