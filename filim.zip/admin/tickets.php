<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Handle ticket cancellation
if (isset($_POST['cancel_ticket'])) {
    $ticket_id = $_POST['ticket_id'];
    
    // Start transaction
    $db->beginTransaction();
    
    try {
        // Get ticket information
        $stmt = $db->prepare("SELECT seat_id FROM tickets WHERE id = ?");
        $stmt->execute([$ticket_id]);
        $ticket = $stmt->fetch();
        
        // Update seat availability
        $stmt = $db->prepare("UPDATE seats SET is_available = 1 WHERE id = ?");
        $stmt->execute([$ticket['seat_id']]);
        
        // Delete payment record
        $stmt = $db->prepare("DELETE FROM payments WHERE ticket_id = ?");
        $stmt->execute([$ticket_id]);
        
        // Delete ticket
        $stmt = $db->prepare("DELETE FROM tickets WHERE id = ?");
        $stmt->execute([$ticket_id]);
        
        $db->commit();
        header('Location: tickets.php');
        exit();
    } catch (Exception $e) {
        $db->rollBack();
        $error = "Bilet iptal edilirken bir hata oluştu.";
    }
}

// Get all tickets with related information
$tickets = $db->query("
    SELECT t.*, 
           m.title as movie_title,
           s.screening_time,
           h.name as hall_name,
           st.seat_number,
           u.name as user_name,
           u.email as user_email,
           p.card_number,
           p.card_holder,
           p.payment_date
    FROM tickets t
    JOIN screenings s ON t.screening_id = s.id
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    JOIN seats st ON t.seat_id = st.id
    JOIN users u ON t.user_id = u.id
    LEFT JOIN payments p ON t.id = p.ticket_id
    ORDER BY t.created_at DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bilet Yönetimi - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Admin Panel</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="movies.php">
                            <i class="fas fa-film"></i> Filmler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="halls.php">
                            <i class="fas fa-door-open"></i> Salonlar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="screenings.php">
                            <i class="fas fa-calendar-alt"></i> Seanslar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users"></i> Kullanıcılar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="payments.php">
                            <i class="fas fa-credit-card"></i> Ödemeler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletler
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <h2 class="mb-4">Bilet Yönetimi</h2>

                <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Bilet No</th>
                                <th>Film</th>
                                <th>Kullanıcı</th>
                                <th>Salon</th>
                                <th>Seans</th>
                                <th>Koltuk</th>
                                <th>Fiyat</th>
                                <th>Ödeme Bilgileri</th>
                                <th>Satın Alma</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tickets as $ticket): ?>
                            <tr>
                                <td>#<?php echo $ticket['id']; ?></td>
                                <td><?php echo htmlspecialchars($ticket['movie_title']); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($ticket['user_name']); ?><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($ticket['user_email']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($ticket['hall_name']); ?></td>
                                <td><?php echo date('d.m.Y H:i', strtotime($ticket['screening_time'])); ?></td>
                                <td><?php echo $ticket['seat_number']; ?></td>
                                <td><?php echo number_format($ticket['total_price'], 2); ?> TL</td>
                                <td>
                                    <?php if ($ticket['card_number']): ?>
                                    <small>
                                        Kart: **** **** **** <?php echo $ticket['card_number']; ?><br>
                                        Sahibi: <?php echo htmlspecialchars($ticket['card_holder']); ?><br>
                                        Tarih: <?php echo date('d.m.Y H:i', strtotime($ticket['payment_date'])); ?>
                                    </small>
                                    <?php else: ?>
                                    <span class="text-muted">Ödeme yok</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('d.m.Y H:i', strtotime($ticket['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 