<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Handle screening deletion
if (isset($_POST['delete_screening'])) {
    $screening_id = $_POST['screening_id'];
    $stmt = $db->prepare("DELETE FROM screenings WHERE id = ?");
    $stmt->execute([$screening_id]);
    header('Location: screenings.php');
    exit();
}

// Handle screening addition/editing
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_screening'])) {
    $movie_id = $_POST['movie_id'];
    $hall_id = $_POST['hall_id'];
    $screening_time = $_POST['screening_time'];
    
    try {
        if (empty($movie_id) || empty($hall_id) || empty($screening_time)) {
            throw new Exception("Lütfen tüm alanları doldurun.");
        }
        
        // Check if the hall is available at the selected time
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM screenings 
            WHERE hall_id = ? AND screening_time = ?
        ");
        $stmt->execute([$hall_id, $screening_time]);
        if ($stmt->fetchColumn() > 0) {
            throw new Exception("Bu salonda seçilen zamanda başka bir seans bulunmaktadır.");
        }
        
        if (isset($_POST['screening_id']) && !empty($_POST['screening_id'])) {
            // Update existing screening
            $stmt = $db->prepare("UPDATE screenings SET movie_id = ?, hall_id = ?, screening_time = ? WHERE id = ?");
            $stmt->execute([$movie_id, $hall_id, $screening_time, $_POST['screening_id']]);
        } else {
            // Add new screening
            $stmt = $db->prepare("INSERT INTO screenings (movie_id, hall_id, screening_time) VALUES (?, ?, ?)");
            $stmt->execute([$movie_id, $hall_id, $screening_time]);
        }
        
        header('Location: screenings.php');
        exit();
    } catch (Exception $e) {
        $error = "Seans kaydedilirken bir hata oluştu: " . $e->getMessage();
    }
}

// Get all screenings with movie and hall information
$screenings = $db->query("
    SELECT s.*, m.title as movie_title, h.name as hall_name,
           (SELECT COUNT(*) FROM tickets t WHERE t.screening_id = s.id) as sold_tickets
    FROM screenings s
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    ORDER BY s.screening_time DESC
")->fetchAll();

// Get all movies for dropdown
$movies = $db->query("SELECT * FROM movies ORDER BY title")->fetchAll();

// Get all halls for dropdown
$halls = $db->query("SELECT * FROM halls ORDER BY name")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seans Yönetimi - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Admin Panel</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="movies.php">
                            <i class="fas fa-film"></i> Filmler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="halls.php">
                            <i class="fas fa-door-open"></i> Salonlar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="screenings.php">
                            <i class="fas fa-calendar-alt"></i> Seanslar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users"></i> Kullanıcılar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="payments.php">
                            <i class="fas fa-credit-card"></i> Ödemeler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletler
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>
                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Seans Yönetimi</h2>
                    <button class="btn btn-primary" data-toggle="modal" data-target="#screeningModal">
                        <i class="fas fa-plus"></i> Yeni Seans Ekle
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Film</th>
                                <th>Salon</th>
                                <th>Seans Zamanı</th>
                                <th>Satılan Bilet</th>
                                <th>İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($screenings as $screening): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($screening['movie_title']); ?></td>
                                <td><?php echo htmlspecialchars($screening['hall_name']); ?></td>
                                <td><?php echo date('d.m.Y H:i', strtotime($screening['screening_time'])); ?></td>
                                <td><?php echo $screening['sold_tickets']; ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info edit-screening" 
                                            data-id="<?php echo $screening['id']; ?>"
                                            data-movie="<?php echo $screening['movie_id']; ?>"
                                            data-hall="<?php echo $screening['hall_id']; ?>"
                                            data-time="<?php echo date('Y-m-d\TH:i', strtotime($screening['screening_time'])); ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Bu seansı silmek istediğinizden emin misiniz?');">
                                        <input type="hidden" name="screening_id" value="<?php echo $screening['id']; ?>">
                                        <button type="submit" name="delete_screening" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Screening Modal -->
    <div class="modal fade" id="screeningModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Seans Ekle/Düzenle</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="screening_id" id="screening_id">
                        <div class="form-group">
                            <label>Film</label>
                            <select name="movie_id" id="movie_id" class="form-control" required>
                                <option value="">Film Seçin</option>
                                <?php foreach ($movies as $movie): ?>
                                <option value="<?php echo $movie['id']; ?>"><?php echo htmlspecialchars($movie['title']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Salon</label>
                            <select name="hall_id" id="hall_id" class="form-control" required>
                                <option value="">Salon Seçin</option>
                                <?php foreach ($halls as $hall): ?>
                                <option value="<?php echo $hall['id']; ?>"><?php echo htmlspecialchars($hall['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Seans Zamanı</label>
                            <input type="datetime-local" name="screening_time" id="screening_time" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">İptal</button>
                        <button type="submit" name="save_screening" class="btn btn-primary">Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.edit-screening').click(function() {
                var id = $(this).data('id');
                var movie = $(this).data('movie');
                var hall = $(this).data('hall');
                var time = $(this).data('time');
                
                $('#screening_id').val(id);
                $('#movie_id').val(movie);
                $('#hall_id').val(hall);
                $('#screening_time').val(time);
                
                $('#screeningModal').modal('show');
            });
        });
    </script>
</body>
</html> 