<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Handle movie deletion
if (isset($_POST['delete_movie'])) {
    $movie_id = $_POST['movie_id'];
    
    try {
        $db->beginTransaction();
        
        // First get all screenings for this movie
        $stmt = $db->prepare("SELECT id FROM screenings WHERE movie_id = ?");
        $stmt->execute([$movie_id]);
        $screenings = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (!empty($screenings)) {
            // Delete payments for tickets of these screenings
            $placeholders = str_repeat('?,', count($screenings) - 1) . '?';
            $stmt = $db->prepare("DELETE FROM payments WHERE ticket_id IN (SELECT id FROM tickets WHERE screening_id IN ($placeholders))");
            $stmt->execute($screenings);
            
            // Delete tickets for these screenings
            $stmt = $db->prepare("DELETE FROM tickets WHERE screening_id IN ($placeholders)");
            $stmt->execute($screenings);
            
            // Delete the screenings
            $stmt = $db->prepare("DELETE FROM screenings WHERE movie_id = ?");
            $stmt->execute([$movie_id]);
        }
        
        // Finally delete the movie
        $stmt = $db->prepare("DELETE FROM movies WHERE id = ?");
        $stmt->execute([$movie_id]);
        
        $db->commit();
        header('Location: movies.php');
        exit();
    } catch (Exception $e) {
        $db->rollBack();
        $error = "Film silinirken bir hata oluştu: " . $e->getMessage();
    }
}

// Handle movie addition/editing
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_movie'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $duration = $_POST['duration'];
    $price = $_POST['price'];
    
    try {
        // Handle image upload
        $image_url = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $target_dir = "../uploads/movies/";
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            
            // Generate unique filename
            $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $new_filename = uniqid() . '_' . time() . '.' . $file_extension;
            $target_file = $target_dir . $new_filename;
            
            // Check file type
            $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($file_extension, $allowed_types)) {
                throw new Exception("Sadece JPG, JPEG, PNG ve GIF dosyaları yüklenebilir.");
            }
            
            // Check file size (max 5MB)
            if ($_FILES['image']['size'] > 5 * 1024 * 1024) {
                throw new Exception("Dosya boyutu 5MB'dan büyük olamaz.");
            }
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_url = $target_file;
            } else {
                throw new Exception("Dosya yüklenirken bir hata oluştu.");
            }
        }
        
        if (isset($_POST['movie_id']) && !empty($_POST['movie_id'])) {
            // Update existing movie
            $stmt = $db->prepare("UPDATE movies SET title = ?, description = ?, duration = ?, price = ?" . 
                ($image_url ? ", image_url = ?" : "") . " WHERE id = ?");
            $params = [$title, $description, $duration, $price];
            if ($image_url) $params[] = $image_url;
            $params[] = $_POST['movie_id'];
            $stmt->execute($params);
        } else {
            // Add new movie
            $stmt = $db->prepare("INSERT INTO movies (title, description, duration, price, image_url) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$title, $description, $duration, $price, $image_url]);
        }
        
        header('Location: movies.php');
        exit();
    } catch (Exception $e) {
        $error = "Film kaydedilirken bir hata oluştu: " . $e->getMessage();
    }
}

// Get all movies
$movies = $db->query("SELECT * FROM movies ORDER BY created_at DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film Yönetimi - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
        .movie-image {
            width: 100px;
            height: 150px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Admin Panel</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="movies.php">
                            <i class="fas fa-film"></i> Filmler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="halls.php">
                            <i class="fas fa-door-open"></i> Salonlar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="screenings.php">
                            <i class="fas fa-calendar-alt"></i> Seanslar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users"></i> Kullanıcılar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="payments.php">
                            <i class="fas fa-credit-card"></i> Ödemeler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletler
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>
                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Film Yönetimi</h2>
                    <button class="btn btn-primary" data-toggle="modal" data-target="#movieModal">
                        <i class="fas fa-plus"></i> Yeni Film Ekle
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Poster</th>
                                <th>Film Adı</th>
                                <th>Açıklama</th>
                                <th>Süre (dk)</th>
                                <th>Fiyat (TL)</th>
                                <th>İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($movies as $movie): ?>
                            <tr>
                                <td>
                                    <?php if ($movie['image_url']): ?>
                                        <img src="<?php echo $movie['image_url']; ?>" class="movie-image" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                                    <?php else: ?>
                                        <div class="movie-image bg-secondary d-flex align-items-center justify-content-center">
                                            <i class="fas fa-film fa-2x text-white"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($movie['title']); ?></td>
                                <td><?php echo htmlspecialchars($movie['description']); ?></td>
                                <td><?php echo $movie['duration']; ?></td>
                                <td><?php echo number_format($movie['price'], 2); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info edit-movie" 
                                            data-id="<?php echo $movie['id']; ?>"
                                            data-title="<?php echo htmlspecialchars($movie['title']); ?>"
                                            data-description="<?php echo htmlspecialchars($movie['description']); ?>"
                                            data-duration="<?php echo $movie['duration']; ?>"
                                            data-price="<?php echo $movie['price']; ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Bu filmi silmek istediğinizden emin misiniz?');">
                                        <input type="hidden" name="movie_id" value="<?php echo $movie['id']; ?>">
                                        <button type="submit" name="delete_movie" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Movie Modal -->
    <div class="modal fade" id="movieModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Film Ekle/Düzenle</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="movie_id" id="movie_id">
                        <div class="form-group">
                            <label>Film Adı</label>
                            <input type="text" name="title" id="title" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Açıklama</label>
                            <textarea name="description" id="description" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Süre (dakika)</label>
                            <input type="number" name="duration" id="duration" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Fiyat (TL)</label>
                            <input type="number" name="price" id="price" class="form-control" step="0.01" required>
                        </div>
                        <div class="form-group">
                            <label>Film Posteri</label>
                            <input type="file" name="image" class="form-control-file" accept="image/*">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">İptal</button>
                        <button type="submit" name="save_movie" class="btn btn-primary">Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.edit-movie').click(function() {
                var id = $(this).data('id');
                var title = $(this).data('title');
                var description = $(this).data('description');
                var duration = $(this).data('duration');
                var price = $(this).data('price');
                
                $('#movie_id').val(id);
                $('#title').val(title);
                $('#description').val(description);
                $('#duration').val(duration);
                $('#price').val(price);
                
                $('#movieModal').modal('show');
            });
        });
    </script>
</body>
</html> 