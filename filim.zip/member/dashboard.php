<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is member
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'member') {
    header('Location: ../login.php');
    exit();
}

// Get user information
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Get all movies with their screenings
$stmt = $db->prepare("
    SELECT m.*, 
           COUNT(DISTINCT s.id) as screening_count,
           MIN(s.screening_time) as next_screening
    FROM movies m
    LEFT JOIN screenings s ON m.id = s.movie_id AND s.screening_time > NOW()
    GROUP BY m.id, m.title, m.description, m.duration, m.price, m.image_url, m.created_at
    ORDER BY m.created_at DESC
");
$stmt->execute();
$movies = $stmt->fetchAll();

// Get user's tickets
$stmt = $db->prepare("
    SELECT t.*, m.title as movie_title, m.image_url, s.screening_time, h.name as hall_name, st.seat_number
    FROM tickets t
    JOIN screenings s ON t.screening_id = s.id
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    JOIN seats st ON t.seat_id = st.id
    WHERE t.user_id = ?
    ORDER BY t.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$tickets = $stmt->fetchAll();

// Get upcoming screenings
$stmt = $db->prepare("
    SELECT s.*, m.title, m.image_url, m.duration, h.name as hall_name,
           (SELECT COUNT(*) FROM tickets t WHERE t.screening_id = s.id) as sold_tickets,
           h.total_seats as total_seats
    FROM screenings s
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    WHERE s.screening_time > NOW()
    ORDER BY s.screening_time ASC
");
$stmt->execute();
$upcoming_screenings = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Üye Paneli - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .movie-card {
            transition: transform 0.2s;
            height: 100%;
        }
        .movie-card:hover {
            transform: translateY(-5px);
        }
        .movie-image {
            height: 300px;
            object-fit: cover;
        }
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Üye Paneli</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletlerim
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> Profilim
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="row mb-4">
                    <div class="col-md-12">
                        <h2>Hoş Geldiniz, <?php echo htmlspecialchars($user['name']); ?>!</h2>
                    </div>
                </div>

                <!-- Recent Tickets -->
                <div class="row mb-4">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Son Biletlerim</h5>
                            </div>
                            <div class="card-body">
                                <?php if (count($tickets) > 0): ?>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Film</th>
                                                <th>Salon</th>
                                                <th>Seans</th>
                                                <th>Koltuk</th>
                                                <th>Fiyat</th>
                                                <th>Satın Alma</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($tickets as $ticket): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($ticket['movie_title']); ?></td>
                                                <td><?php echo htmlspecialchars($ticket['hall_name']); ?></td>
                                                <td><?php echo date('d.m.Y H:i', strtotime($ticket['screening_time'])); ?></td>
                                                <td><?php echo $ticket['seat_number']; ?></td>
                                                <td><?php echo number_format($ticket['total_price'], 2); ?> TL</td>
                                                <td><?php echo date('d.m.Y H:i', strtotime($ticket['created_at'])); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php else: ?>
                                <p class="text-muted">Henüz bilet satın almadınız.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Movies -->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="mb-4">Filmler</h3>
                    </div>
                    <?php foreach ($movies as $movie): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card movie-card">
                            <?php if ($movie['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" class="card-img-top movie-image" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                            <?php else: ?>
                            <div class="card-img-top movie-image bg-secondary d-flex align-items-center justify-content-center">
                                <i class="fas fa-film fa-3x text-white"></i>
                            </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($movie['title']); ?></h5>
                                <p class="card-text">
                                    <i class="fas fa-clock"></i> Süre: <?php echo $movie['duration']; ?> dakika<br>
                                    <i class="fas fa-ticket-alt"></i> Fiyat: <?php echo number_format($movie['price'], 2); ?> TL<br>
                                    <?php if ($movie['screening_count'] > 0): ?>
                                    <i class="fas fa-calendar"></i> İlk Seans: <?php echo date('d.m.Y H:i', strtotime($movie['next_screening'])); ?>
                                    <?php else: ?>
                                    <i class="fas fa-info-circle"></i> Henüz seans yok
                                    <?php endif; ?>
                                </p>
                                <?php if ($movie['screening_count'] > 0): ?>
                                <a href="buy_ticket.php?movie_id=<?php echo $movie['id']; ?>" class="btn btn-primary btn-block">
                                    <i class="fas fa-ticket-alt"></i> Bilet Al
                                </a>
                                <?php else: ?>
                                <button class="btn btn-secondary btn-block" disabled>
                                    <i class="fas fa-ticket-alt"></i> Seans Yok
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 