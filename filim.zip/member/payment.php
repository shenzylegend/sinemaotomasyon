<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'member') {
    header('Location: ../login.php');
    exit();
}

if (!isset($_GET['screening_id']) || !isset($_GET['seat_id'])) {
    header('Location: dashboard.php');
    exit();
}

$screening_id = $_GET['screening_id'];
$seat_id = $_GET['seat_id'];

// Get screening and movie details
$stmt = $db->prepare("
    SELECT s.*, m.title, m.price, h.name as hall_name, st.seat_number
    FROM screenings s
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    JOIN seats st ON st.id = ?
    WHERE s.id = ?
");
$stmt->execute([$seat_id, $screening_id]);
$ticket_info = $stmt->fetch();

if (!$ticket_info) {
    header('Location: dashboard.php');
    exit();
}

// Process payment
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $db->beginTransaction();

        // Create ticket
        $stmt = $db->prepare("
            INSERT INTO tickets (user_id, screening_id, seat_id, total_price)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$_SESSION['user_id'], $screening_id, $seat_id, $ticket_info['price']]);
        $ticket_id = $db->lastInsertId();

        // Record payment
        $stmt = $db->prepare("
            INSERT INTO payments (ticket_id, card_number, card_holder, amount)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $ticket_id,
            substr($_POST['card_number'], -4), // Store only last 4 digits
            $_POST['card_holder'],
            $ticket_info['price']
        ]);

        $db->commit();
        header('Location: ticket-confirmation.php?id=' . $ticket_id);
        exit();
    } catch (Exception $e) {
        $db->rollBack();
        $error = "Ödeme işlemi sırasında bir hata oluştu.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ödeme - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Sinema Otomasyonu</a>
            <a class="btn btn-outline-light" href="../logout.php">Çıkış Yap</a>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mb-0">Ödeme Bilgileri</h3>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <div class="alert alert-info">
                            <h5>Bilet Bilgileri</h5>
                            <p><strong>Film:</strong> <?php echo htmlspecialchars($ticket_info['title']); ?></p>
                            <p><strong>Seans:</strong> <?php echo date('d.m.Y H:i', strtotime($ticket_info['screening_time'])); ?></p>
                            <p><strong>Salon:</strong> <?php echo htmlspecialchars($ticket_info['hall_name']); ?></p>
                            <p><strong>Koltuk:</strong> <?php echo htmlspecialchars($ticket_info['seat_number']); ?></p>
                            <p><strong>Fiyat:</strong> <?php echo number_format($ticket_info['price'], 2); ?> TL</p>
                        </div>

                        <form method="POST" action="">
                            <div class="form-group">
                                <label>Kart Üzerindeki İsim</label>
                                <input type="text" name="card_holder" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label>Kart Numarası</label>
                                <input type="text" name="card_number" class="form-control" 
                                       pattern="[0-9]{16}" maxlength="16" required
                                       placeholder="1234 5678 9012 3456">
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Son Kullanma Tarihi</label>
                                        <input type="text" name="expiry" class="form-control" 
                                               pattern="[0-9]{2}/[0-9]{2}" maxlength="5" required
                                               placeholder="MM/YY">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>CVV</label>
                                        <input type="text" name="cvv" class="form-control" 
                                               pattern="[0-9]{3}" maxlength="3" required
                                               placeholder="123">
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block btn-lg">
                                <?php echo number_format($ticket_info['price'], 2); ?> TL Öde
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Format card number input
        $('input[name="card_number"]').on('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
        });

        // Format expiry date input
        $('input[name="expiry"]').on('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
            if (this.value.length >= 2) {
                this.value = this.value.slice(0,2) + '/' + this.value.slice(2);
            }
        });

        // Format CVV input
        $('input[name="cvv"]').on('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>
</body>
</html> 