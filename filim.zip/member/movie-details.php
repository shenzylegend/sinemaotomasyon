<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'member') {
    header('Location: ../login.php');
    exit();
}

if (!isset($_GET['id'])) {
    header('Location: dashboard.php');
    exit();
}

$movie_id = $_GET['id'];

// Get movie details
$stmt = $db->prepare("SELECT * FROM movies WHERE id = ?");
$stmt->execute([$movie_id]);
$movie = $stmt->fetch();

if (!$movie) {
    header('Location: dashboard.php');
    exit();
}

// Get screenings for this movie
$stmt = $db->prepare("
    SELECT s.*, h.name as hall_name 
    FROM screenings s 
    JOIN halls h ON s.hall_id = h.id 
    WHERE s.movie_id = ? AND s.screening_time > NOW()
    ORDER BY s.screening_time
");
$stmt->execute([$movie_id]);
$screenings = $stmt->fetchAll();

// Get selected screening's seats if screening is selected
$selected_screening = null;
$seats = [];
if (isset($_GET['screening_id'])) {
    $stmt = $db->prepare("
        SELECT s.*, h.name as hall_name 
        FROM screenings s 
        JOIN halls h ON s.hall_id = h.id 
        WHERE s.id = ?
    ");
    $stmt->execute([$_GET['screening_id']]);
    $selected_screening = $stmt->fetch();

    if ($selected_screening) {
        // Get seats for this screening
        $stmt = $db->prepare("
            SELECT s.*, 
                   CASE WHEN t.id IS NOT NULL THEN 0 ELSE 1 END as is_available
            FROM seats s
            LEFT JOIN tickets t ON s.id = t.seat_id 
            AND t.screening_id = ?
            WHERE s.hall_id = ?
        ");
        $stmt->execute([$_GET['screening_id'], $selected_screening['hall_id']]);
        $seats = $stmt->fetchAll();
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($movie['title']); ?> - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .seat {
            width: 40px;
            height: 40px;
            margin: 5px;
            display: inline-block;
            text-align: center;
            line-height: 40px;
            cursor: pointer;
            border-radius: 5px;
        }
        .seat.available {
            background-color: #28a745;
            color: white;
        }
        .seat.selected {
            background-color: #007bff;
            color: white;
        }
        .seat.occupied {
            background-color: #dc3545;
            color: white;
            cursor: not-allowed;
        }
        .screen {
            background-color: #333;
            color: white;
            padding: 20px;
            text-align: center;
            margin-bottom: 30px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Sinema Otomasyonu</a>
            <a class="btn btn-outline-light" href="../logout.php">Çıkış Yap</a>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-4">
                <?php if ($movie['image_url']): ?>
                <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" class="img-fluid rounded" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                <?php endif; ?>
            </div>
            <div class="col-md-8">
                <h1><?php echo htmlspecialchars($movie['title']); ?></h1>
                <p><?php echo nl2br(htmlspecialchars($movie['description'])); ?></p>
                <p><strong>Süre:</strong> <?php echo $movie['duration']; ?> dakika</p>
                <p><strong>Fiyat:</strong> <?php echo number_format($movie['price'], 2); ?> TL</p>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <h3>Seans Seçimi</h3>
                <div class="row">
                    <?php foreach ($screenings as $screening): ?>
                    <div class="col-md-3 mb-3">
                        <a href="?id=<?php echo $movie_id; ?>&screening_id=<?php echo $screening['id']; ?>" 
                           class="btn btn-outline-primary btn-block <?php echo (isset($_GET['screening_id']) && $_GET['screening_id'] == $screening['id']) ? 'active' : ''; ?>">
                            <?php echo date('d.m.Y H:i', strtotime($screening['screening_time'])); ?><br>
                            <small><?php echo htmlspecialchars($screening['hall_name']); ?></small>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <?php if ($selected_screening): ?>
        <div class="row mt-4">
            <div class="col-12">
                <div class="screen">
                    <h4>PERDE</h4>
                </div>
                <div class="text-center">
                    <?php foreach ($seats as $seat): ?>
                    <div class="seat <?php echo $seat['is_available'] ? 'available' : 'occupied'; ?>" 
                         data-seat-id="<?php echo $seat['id']; ?>"
                         <?php echo $seat['is_available'] ? '' : 'disabled'; ?>>
                        <?php echo $seat['seat_number']; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="mt-4 text-center">
                    <button id="buyTicket" class="btn btn-primary btn-lg" disabled>Bilet Al</button>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            let selectedSeat = null;

            $('.seat.available').click(function() {
                if (selectedSeat) {
                    $(selectedSeat).removeClass('selected').addClass('available');
                }
                $(this).removeClass('available').addClass('selected');
                selectedSeat = this;
                $('#buyTicket').prop('disabled', false);
            });

            $('#buyTicket').click(function() {
                if (selectedSeat) {
                    const seatId = $(selectedSeat).data('seat-id');
                    window.location.href = `payment.php?screening_id=<?php echo $_GET['screening_id']; ?>&seat_id=${seatId}`;
                }
            });
        });
    </script>
</body>
</html> 