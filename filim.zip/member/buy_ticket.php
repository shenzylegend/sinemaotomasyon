<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is member
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'member') {
    header('Location: ../login.php');
    exit();
}

// Check if movie_id is provided
if (!isset($_GET['movie_id'])) {
    header('Location: dashboard.php');
    exit();
}

$movie_id = $_GET['movie_id'];

// Get movie information
$stmt = $db->prepare("
    SELECT * FROM movies WHERE id = ?
");
$stmt->execute([$movie_id]);
$movie = $stmt->fetch();

if (!$movie) {
    header('Location: dashboard.php');
    exit();
}

// Get upcoming screenings for this movie
$stmt = $db->prepare("
    SELECT s.*, h.name as hall_name,
           (SELECT COUNT(*) FROM tickets t WHERE t.screening_id = s.id) as sold_tickets,
           h.total_seats
    FROM screenings s
    JOIN halls h ON s.hall_id = h.id
    WHERE s.movie_id = ? AND s.screening_time > NOW()
    ORDER BY s.screening_time ASC
");
$stmt->execute([$movie_id]);
$screenings = $stmt->fetchAll();

// Handle ticket purchase
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buy_ticket'])) {
    $screening_id = $_POST['screening_id'];
    $seat_id = $_POST['seat_id'];
    $card_number = $_POST['card_number'];
    $card_holder = $_POST['card_holder'];
    $expiry = $_POST['expiry'];
    $cvv = $_POST['cvv'];
    
    // Start transaction
    $db->beginTransaction();
    
    try {
        // Check if seat is still available
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM tickets 
            WHERE seat_id = ? AND screening_id = ?
        ");
        $stmt->execute([$seat_id, $screening_id]);
        if ($stmt->fetchColumn() > 0) {
            throw new Exception("Seçilen koltuk başka bir kullanıcı tarafından satın alındı.");
        }
        
        // Get seat number for confirmation
        $stmt = $db->prepare("SELECT seat_number FROM seats WHERE id = ?");
        $stmt->execute([$seat_id]);
        $seat_number = $stmt->fetchColumn();
        
        // Create ticket
        $stmt = $db->prepare("
            INSERT INTO tickets (user_id, screening_id, seat_id, total_price, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$_SESSION['user_id'], $screening_id, $seat_id, $movie['price']]);
        $ticket_id = $db->lastInsertId();
        
        // Create payment record
        $stmt = $db->prepare("
            INSERT INTO payments (ticket_id, card_number, card_holder, amount, payment_date)
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $ticket_id,
            substr($card_number, -4), // Store only last 4 digits for security
            $card_holder,
            $movie['price']
        ]);
        
        $db->commit();
        
        // Set success message
        $_SESSION['success_message'] = "Bilet başarıyla satın alındı! Bilet numaranız: " . $ticket_id;
        header('Location: tickets.php');
        exit();
    } catch (Exception $e) {
        $db->rollBack();
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bilet Al - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
        .seat {
            width: 40px;
            height: 40px;
            margin: 5px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border-radius: 5px;
        }
        .seat.available {
            background-color: #28a745;
            color: white;
        }
        .seat.occupied {
            background-color: #dc3545;
            color: white;
            cursor: not-allowed;
        }
        .seat.selected {
            background-color: #17a2b8;
            color: white;
        }
        .screen {
            background: #343a40;
            color: white;
            padding: 20px;
            text-align: center;
            margin-bottom: 30px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Üye Paneli</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletlerim
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> Profilim
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <h2 class="mb-4">Bilet Al</h2>

                <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <?php if ($movie['image_url']): ?>
                                <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" class="img-fluid rounded" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                                <?php else: ?>
                                <div class="bg-secondary rounded d-flex align-items-center justify-content-center" style="height: 300px;">
                                    <i class="fas fa-film fa-3x text-white"></i>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-8">
                                <h4><?php echo htmlspecialchars($movie['title']); ?></h4>
                                <p>
                                    <i class="fas fa-clock"></i> Süre: <?php echo $movie['duration']; ?> dakika<br>
                                    <i class="fas fa-ticket-alt"></i> Fiyat: <?php echo number_format($movie['price'], 2); ?> TL<br>
                                    <i class="fas fa-info-circle"></i> <?php echo htmlspecialchars($movie['description']); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if (count($screenings) > 0): ?>
                <div class="row">
                    <?php foreach ($screenings as $screening): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <i class="fas fa-calendar"></i> <?php echo date('d.m.Y H:i', strtotime($screening['screening_time'])); ?>
                                </h5>
                                <p class="card-text">
                                    <i class="fas fa-door-open"></i> <?php echo htmlspecialchars($screening['hall_name']); ?><br>
                                    <i class="fas fa-chair"></i> <?php echo $screening['sold_tickets']; ?>/<?php echo $screening['total_seats']; ?> Koltuk
                                </p>
                                <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#seatsModal<?php echo $screening['id']; ?>">
                                    <i class="fas fa-ticket-alt"></i> Koltuk Seç
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Seats Modal -->
                    <div class="modal fade" id="seatsModal<?php echo $screening['id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Koltuk Seçimi</h5>
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span>&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form method="POST" id="ticketForm<?php echo $screening['id']; ?>">
                                        <input type="hidden" name="screening_id" value="<?php echo $screening['id']; ?>">
                                        <input type="hidden" name="seat_id" id="seat_id<?php echo $screening['id']; ?>">
                                        
                                        <div class="screen">
                                            <i class="fas fa-film fa-2x"></i> EKRAN
                                        </div>

                                        <div class="text-center mb-4">
                                            <?php
                                            // Get available seats for this screening
                                            $stmt = $db->prepare("
                                                SELECT s.*, 
                                                       CASE WHEN t.id IS NULL THEN 1 ELSE 0 END as is_available
                                                FROM seats s
                                                LEFT JOIN tickets t ON s.id = t.seat_id AND t.screening_id = ?
                                                WHERE s.hall_id = ?
                                                ORDER BY s.seat_number
                                            ");
                                            $stmt->execute([$screening['id'], $screening['hall_id']]);
                                            $seats = $stmt->fetchAll();

                                            $current_row = '';
                                            foreach ($seats as $seat) {
                                                $row = substr($seat['seat_number'], 0, 1);
                                                if ($row !== $current_row) {
                                                    if ($current_row !== '') echo '<br>';
                                                    $current_row = $row;
                                                }
                                                ?>
                                                <div class="seat <?php echo $seat['is_available'] ? 'available' : 'occupied'; ?>"
                                                     data-seat-id="<?php echo $seat['id']; ?>"
                                                     data-seat-number="<?php echo $seat['seat_number']; ?>"
                                                     onclick="selectSeat(<?php echo $screening['id']; ?>, <?php echo $seat['id']; ?>, '<?php echo $seat['seat_number']; ?>', <?php echo $seat['is_available'] ? 'true' : 'false'; ?>)">
                                                    <?php echo $seat['seat_number']; ?>
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>

                                        <div class="text-center">
                                            <button type="button" class="btn btn-primary btn-lg" id="buyButton<?php echo $screening['id']; ?>" disabled onclick="showPaymentForm(<?php echo $screening['id']; ?>)">
                                                <i class="fas fa-ticket-alt"></i> Bilet Al
                                            </button>
                                            <div class="mt-2 text-muted" id="selectedSeatInfo<?php echo $screening['id']; ?>"></div>
                                        </div>

                                        <!-- Payment Form -->
                                        <div id="paymentForm<?php echo $screening['id']; ?>" style="display: none;" class="mt-4">
                                            <h5 class="mb-3">Ödeme Bilgileri</h5>
                                            <div class="form-group">
                                                <label>Kart Üzerindeki İsim</label>
                                                <input type="text" name="card_holder" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Kart Numarası</label>
                                                <input type="text" name="card_number" class="form-control" pattern="[0-9]{16}" maxlength="16" required placeholder="1234 5678 9012 3456">
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Son Kullanma Tarihi</label>
                                                        <input type="text" name="expiry" class="form-control" pattern="[0-9]{2}/[0-9]{2}" maxlength="5" required placeholder="MM/YY">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>CVV</label>
                                                        <input type="text" name="cvv" class="form-control" pattern="[0-9]{3}" maxlength="3" required placeholder="123">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="text-center">
                                                <button type="submit" name="buy_ticket" class="btn btn-success btn-lg">
                                                    <i class="fas fa-check"></i> Ödemeyi Tamamla
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Bu film için henüz seans bulunmuyor.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        function selectSeat(screeningId, seatId, seatNumber, isAvailable) {
            if (!isAvailable) return;
            
            // Reset all seats in this modal
            $('#seatsModal' + screeningId + ' .seat').removeClass('selected');
            
            // Select the clicked seat
            $('#seatsModal' + screeningId + ' .seat[data-seat-id="' + seatId + '"]').addClass('selected');
            
            // Update hidden input and enable buy button
            $('#seat_id' + screeningId).val(seatId);
            $('#buyButton' + screeningId).prop('disabled', false);
            
            // Show selected seat info
            $('#selectedSeatInfo' + screeningId).html(
                '<i class="fas fa-info-circle"></i> Seçilen Koltuk: ' + seatNumber
            );
        }

        function showPaymentForm(screeningId) {
            $('#paymentForm' + screeningId).slideDown();
            $('#buyButton' + screeningId).hide();
        }

        // Format card number input
        $('input[name="card_number"]').on('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
        });

        // Format expiry date input
        $('input[name="expiry"]').on('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
            if (this.value.length >= 2) {
                this.value = this.value.slice(0,2) + '/' + this.value.slice(2);
            }
        });

        // Format CVV input
        $('input[name="cvv"]').on('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>
</body>
</html> 