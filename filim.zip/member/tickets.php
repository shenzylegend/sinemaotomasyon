<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is member
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'member') {
    header('Location: ../login.php');
    exit();
}

// Get user's tickets
$stmt = $db->prepare("
    SELECT t.*, m.title as movie_title, m.image_url, s.screening_time, h.name as hall_name, st.seat_number,
           p.card_number, p.card_holder, p.payment_date
    FROM tickets t
    JOIN screenings s ON t.screening_id = s.id
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    JOIN seats st ON t.seat_id = st.id
    LEFT JOIN payments p ON t.id = p.ticket_id
    WHERE t.user_id = ?
    ORDER BY t.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$tickets = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biletlerim - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
        .ticket-card {
            transition: transform 0.2s;
        }
        .ticket-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Üye Paneli</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletlerim
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> Profilim
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <h2 class="mb-4">Biletlerim</h2>

                <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success_message']; ?>
                </div>
                <?php unset($_SESSION['success_message']); ?>
                <?php endif; ?>

                <?php if (count($tickets) > 0): ?>
                <div class="row">
                    <?php foreach ($tickets as $ticket): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card ticket-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h5 class="card-title mb-0"><?php echo htmlspecialchars($ticket['movie_title']); ?></h5>
                                    <span class="badge badge-primary"><?php echo number_format($ticket['total_price'], 2); ?> TL</span>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-2">
                                            <i class="fas fa-calendar-alt"></i> Seans: <?php echo date('d.m.Y H:i', strtotime($ticket['screening_time'])); ?>
                                        </p>
                                        <p class="mb-2">
                                            <i class="fas fa-door-open"></i> Salon: <?php echo htmlspecialchars($ticket['hall_name']); ?>
                                        </p>
                                        <p class="mb-2">
                                            <i class="fas fa-chair"></i> Koltuk: <?php echo $ticket['seat_number']; ?>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-2">
                                            <i class="fas fa-credit-card"></i> Kart: **** **** **** <?php echo $ticket['card_number']; ?>
                                        </p>
                                        <p class="mb-2">
                                            <i class="fas fa-user"></i> Kart Sahibi: <?php echo htmlspecialchars($ticket['card_holder']); ?>
                                        </p>
                                        <p class="mb-2">
                                            <i class="fas fa-clock"></i> Satın Alma: <?php echo date('d.m.Y H:i', strtotime($ticket['created_at'])); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="text-center mt-3">
                                    <button class="btn btn-outline-primary" onclick="window.print()">
                                        <i class="fas fa-print"></i> Bileti Yazdır
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Henüz bilet satın almadınız.
                    <a href="dashboard.php" class="alert-link">Film seçmek için tıklayın</a>.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 