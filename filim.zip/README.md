merhaba ben helin bu otomasyon php html kullanılarak geliştirilmiştir 

kurulum adımları olarak config dosyasındaki bilgileri düzenlemeniz yeterli olacaktır.