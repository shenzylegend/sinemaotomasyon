<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is manager
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'manager') {
    header('Location: ../login.php');
    exit();
}

// Handle ticket cancellation
if (isset($_POST['cancel_ticket'])) {
    $ticket_id = $_POST['ticket_id'];
    
    try {
        // Start transaction
        $db->beginTransaction();
        
        // Get ticket information
        $stmt = $db->prepare("SELECT seat_id FROM tickets WHERE id = ?");
        $stmt->execute([$ticket_id]);
        $ticket = $stmt->fetch();
        
        // Update seat availability
        $stmt = $db->prepare("UPDATE seats SET is_available = 1 WHERE id = ?");
        $stmt->execute([$ticket['seat_id']]);
        
        // Delete payment record
        $stmt = $db->prepare("DELETE FROM payments WHERE ticket_id = ?");
        $stmt->execute([$ticket_id]);
        
        // Delete ticket
        $stmt = $db->prepare("DELETE FROM tickets WHERE id = ?");
        $stmt->execute([$ticket_id]);
        
        $db->commit();
        $_SESSION['success_message'] = "Bilet başarıyla iptal edildi.";
    } catch (Exception $e) {
        $db->rollBack();
        $_SESSION['error_message'] = "Bilet iptal edilirken bir hata oluştu.";
    }
    
    header('Location: tickets.php');
    exit();
}

// Get all tickets with related information
$tickets = $db->query("
    SELECT t.*, 
           m.title as movie_title,
           m.image_url,
           s.screening_time,
           h.name as hall_name,
           st.seat_number,
           u.name as user_name,
           u.email as user_email,
           p.card_number,
           p.card_holder,
           p.payment_date
    FROM tickets t
    JOIN screenings s ON t.screening_id = s.id
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    JOIN seats st ON t.seat_id = st.id
    JOIN users u ON t.user_id = u.id
    LEFT JOIN payments p ON t.id = p.ticket_id
    ORDER BY t.created_at DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bilet Yönetimi - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Yönetici Paneli</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="movies.php">
                            <i class="fas fa-film"></i> Filmler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="screenings.php">
                            <i class="fas fa-calendar-alt"></i> Seanslar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> Profilim
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <h2 class="mb-4">Bilet Yönetimi</h2>

                <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success_message']; ?>
                </div>
                <?php unset($_SESSION['success_message']); ?>
                <?php endif; ?>

                <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error_message']; ?>
                </div>
                <?php unset($_SESSION['error_message']); ?>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Bilet No</th>
                                <th>Film</th>
                                <th>Kullanıcı</th>
                                <th>Seans</th>
                                <th>Salon</th>
                                <th>Koltuk</th>
                                <th>Fiyat</th>
                                <th>Ödeme Bilgileri</th>
                                <th>Satın Alma</th>
                                <th>İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tickets as $ticket): ?>
                            <tr>
                                <td>#<?php echo $ticket['id']; ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <?php if ($ticket['image_url']): ?>
                                        <img src="<?php echo htmlspecialchars($ticket['image_url']); ?>" class="mr-2" style="width: 40px; height: 60px; object-fit: cover;">
                                        <?php endif; ?>
                                        <?php echo htmlspecialchars($ticket['movie_title']); ?>
                                    </div>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($ticket['user_name']); ?><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($ticket['user_email']); ?></small>
                                </td>
                                <td><?php echo date('d.m.Y H:i', strtotime($ticket['screening_time'])); ?></td>
                                <td><?php echo htmlspecialchars($ticket['hall_name']); ?></td>
                                <td><?php echo $ticket['seat_number']; ?></td>
                                <td><?php echo number_format($ticket['total_price'], 2); ?> TL</td>
                                <td>
                                    <?php if ($ticket['card_number']): ?>
                                    <small>
                                        Kart: **** **** **** <?php echo $ticket['card_number']; ?><br>
                                        Sahibi: <?php echo htmlspecialchars($ticket['card_holder']); ?><br>
                                        Tarih: <?php echo date('d.m.Y H:i', strtotime($ticket['payment_date'])); ?>
                                    </small>
                                    <?php else: ?>
                                    <span class="text-muted">Ödeme yok</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('d.m.Y H:i', strtotime($ticket['created_at'])); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#cancelModal<?php echo $ticket['id']; ?>">
                                        <i class="fas fa-times"></i> İptal
                                    </button>
                                </td>
                            </tr>

                            <!-- Cancel Modal -->
                            <div class="modal fade" id="cancelModal<?php echo $ticket['id']; ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Bilet İptali</h5>
                                            <button type="button" class="close" data-dismiss="modal">
                                                <span>&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <p><strong>#<?php echo $ticket['id']; ?></strong> numaralı bileti iptal etmek istediğinizden emin misiniz?</p>
                                            <p class="text-danger">Bu işlem geri alınamaz ve ödeme kaydı da silinecektir.</p>
                                        </div>
                                        <div class="modal-footer">
                                            <form method="POST">
                                                <input type="hidden" name="ticket_id" value="<?php echo $ticket['id']; ?>">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">İptal</button>
                                                <button type="submit" name="cancel_ticket" class="btn btn-danger">Bileti İptal Et</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 