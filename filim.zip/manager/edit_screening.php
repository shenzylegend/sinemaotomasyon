<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is manager
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'manager') {
    header('Location: ../login.php');
    exit();
}

// Check if screening ID is provided
if (!isset($_GET['id'])) {
    header('Location: screenings.php');
    exit();
}

$screening_id = $_GET['id'];

// Get screening details
$stmt = $db->prepare("
    SELECT s.*, m.title as movie_title, h.name as hall_name
    FROM screenings s
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    WHERE s.id = ?
");
$stmt->execute([$screening_id]);
$screening = $stmt->fetch();

if (!$screening) {
    header('Location: screenings.php');
    exit();
}

// Get all movies
$movies = $db->query("SELECT id, title FROM movies ORDER BY title")->fetchAll();

// Get all halls
$halls = $db->query("SELECT id, name, total_seats FROM halls ORDER BY name")->fetchAll();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $movie_id = $_POST['movie_id'];
    $hall_id = $_POST['hall_id'];
    $screening_time = $_POST['screening_time'];

    try {
        // Check if hall is available at the selected time (excluding current screening)
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM screenings 
            WHERE hall_id = ? AND screening_time = ? AND id != ?
        ");
        $stmt->execute([$hall_id, $screening_time, $screening_id]);
        
        if ($stmt->fetchColumn() > 0) {
            throw new Exception("Bu salonda seçilen zamanda başka bir seans bulunmaktadır.");
        }

        // Get movie duration
        $stmt = $db->prepare("SELECT duration FROM movies WHERE id = ?");
        $stmt->execute([$movie_id]);
        $movie_duration = $stmt->fetchColumn();

        // Check for overlapping screenings (excluding current screening)
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM screenings 
            WHERE hall_id = ? AND id != ? AND (
                (screening_time <= ? AND DATE_ADD(screening_time, INTERVAL (SELECT duration FROM movies WHERE id = movie_id) MINUTE) > ?)
                OR
                (screening_time < DATE_ADD(?, INTERVAL ? MINUTE) AND DATE_ADD(screening_time, INTERVAL (SELECT duration FROM movies WHERE id = movie_id) MINUTE) >= ?)
            )
        ");
        $stmt->execute([
            $hall_id,
            $screening_id,
            $screening_time,
            $screening_time,
            $screening_time,
            $movie_duration,
            $screening_time
        ]);

        if ($stmt->fetchColumn() > 0) {
            throw new Exception("Bu salonda seçilen zaman diliminde başka bir seans bulunmaktadır.");
        }

        // Update screening
        $stmt = $db->prepare("
            UPDATE screenings 
            SET movie_id = ?, hall_id = ?, screening_time = ?
            WHERE id = ?
        ");
        $stmt->execute([$movie_id, $hall_id, $screening_time, $screening_id]);
        
        $_SESSION['success_message'] = "Seans başarıyla güncellendi.";
        header('Location: screenings.php');
        exit();
    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seans Düzenle - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Yönetici Paneli</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="movies.php">
                            <i class="fas fa-film"></i> Filmler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="screenings.php">
                            <i class="fas fa-calendar-alt"></i> Seanslar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> Profilim
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Seans Düzenle</h2>
                    <a href="screenings.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Geri Dön
                    </a>
                </div>

                <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error_message']; ?>
                </div>
                <?php unset($_SESSION['error_message']); ?>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body">
                        <form method="POST">
                            <div class="form-group">
                                <label for="movie_id">Film</label>
                                <select class="form-control" id="movie_id" name="movie_id" required>
                                    <option value="">Film Seçin</option>
                                    <?php foreach ($movies as $movie): ?>
                                    <option value="<?php echo $movie['id']; ?>" <?php echo $movie['id'] == $screening['movie_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($movie['title']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="hall_id">Salon</label>
                                <select class="form-control" id="hall_id" name="hall_id" required>
                                    <option value="">Salon Seçin</option>
                                    <?php foreach ($halls as $hall): ?>
                                    <option value="<?php echo $hall['id']; ?>" <?php echo $hall['id'] == $screening['hall_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($hall['name']); ?> 
                                        (<?php echo $hall['total_seats']; ?> koltuk)
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="screening_time">Seans Zamanı</label>
                                <input type="datetime-local" class="form-control" id="screening_time" name="screening_time" 
                                       value="<?php echo date('Y-m-d\TH:i', strtotime($screening['screening_time'])); ?>" required>
                            </div>

                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Kaydet
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 