<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is manager
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'manager') {
    header('Location: ../login.php');
    exit();
}

// Handle screening deletion
if (isset($_POST['delete_screening'])) {
    $screening_id = $_POST['screening_id'];
    
    try {
        // Start transaction
        $db->beginTransaction();
        
        // Delete related records
        $stmt = $db->prepare("DELETE FROM tickets WHERE screening_id = ?");
        $stmt->execute([$screening_id]);
        
        // Delete screening
        $stmt = $db->prepare("DELETE FROM screenings WHERE id = ?");
        $stmt->execute([$screening_id]);
        
        $db->commit();
        $_SESSION['success_message'] = "Seans başarıyla silindi.";
    } catch (Exception $e) {
        $db->rollBack();
        $_SESSION['error_message'] = "Seans silinirken bir hata oluştu.";
    }
    
    header('Location: screenings.php');
    exit();
}

// Get all screenings with related information
$screenings = $db->query("
    SELECT s.*, 
           m.title as movie_title,
           m.image_url,
           h.name as hall_name,
           h.total_seats,
           (SELECT COUNT(*) FROM tickets t WHERE t.screening_id = s.id) as sold_tickets,
           COALESCE(SUM(t.total_price), 0) as total_revenue
    FROM screenings s
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    LEFT JOIN tickets t ON s.id = t.screening_id
    GROUP BY s.id
    ORDER BY s.screening_time DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seans Yönetimi - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
        .screening-card {
            transition: transform 0.2s;
        }
        .screening-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Yönetici Paneli</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="movies.php">
                            <i class="fas fa-film"></i> Filmler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="screenings.php">
                            <i class="fas fa-calendar-alt"></i> Seanslar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> Profilim
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Seans Yönetimi</h2>
                    <a href="add_screening.php" class="btn btn-success">
                        <i class="fas fa-plus"></i> Yeni Seans Ekle
                    </a>
                </div>

                <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success_message']; ?>
                </div>
                <?php unset($_SESSION['success_message']); ?>
                <?php endif; ?>

                <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error_message']; ?>
                </div>
                <?php unset($_SESSION['error_message']); ?>
                <?php endif; ?>

                <div class="row">
                    <?php foreach ($screenings as $screening): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card screening-card">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <?php if ($screening['image_url']): ?>
                                    <img src="<?php echo htmlspecialchars($screening['image_url']); ?>" class="mr-3" style="width: 60px; height: 90px; object-fit: cover;">
                                    <?php else: ?>
                                    <div class="bg-secondary mr-3 d-flex align-items-center justify-content-center" style="width: 60px; height: 90px;">
                                        <i class="fas fa-film text-white"></i>
                                    </div>
                                    <?php endif; ?>
                                    <div>
                                        <h5 class="card-title mb-0"><?php echo htmlspecialchars($screening['movie_title']); ?></h5>
                                        <small class="text-muted">
                                            <i class="fas fa-calendar"></i> <?php echo date('d.m.Y H:i', strtotime($screening['screening_time'])); ?>
                                        </small>
                                    </div>
                                </div>
                                <p class="card-text">
                                    <i class="fas fa-door-open"></i> <?php echo htmlspecialchars($screening['hall_name']); ?><br>
                                    <i class="fas fa-chair"></i> <?php echo $screening['sold_tickets']; ?>/<?php echo $screening['total_seats']; ?> Koltuk<br>
                                    <i class="fas fa-money-bill-wave"></i> <?php echo number_format($screening['total_revenue'], 2); ?> TL gelir
                                </p>
                                <div class="progress mb-3">
                                    <?php 
                                    $percentage = ($screening['sold_tickets'] / $screening['total_seats']) * 100;
                                    $color = $percentage > 80 ? 'danger' : ($percentage > 50 ? 'warning' : 'success');
                                    ?>
                                    <div class="progress-bar bg-<?php echo $color; ?>" 
                                         role="progressbar" 
                                         style="width: <?php echo $percentage; ?>%">
                                        <?php echo round($percentage); ?>%
                                    </div>
                                </div>
                                <div class="btn-group w-100">
                                    <a href="edit_screening.php?id=<?php echo $screening['id']; ?>" class="btn btn-primary">
                                        <i class="fas fa-edit"></i> Düzenle
                                    </a>
                                    <a href="view_tickets.php?screening_id=<?php echo $screening['id']; ?>" class="btn btn-info">
                                        <i class="fas fa-ticket-alt"></i> Biletler
                                    </a>
                                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteModal<?php echo $screening['id']; ?>">
                                        <i class="fas fa-trash"></i> Sil
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Delete Modal -->
                    <div class="modal fade" id="deleteModal<?php echo $screening['id']; ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Seans Sil</h5>
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span>&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p><strong><?php echo htmlspecialchars($screening['movie_title']); ?></strong> filminin seansını silmek istediğinizden emin misiniz?</p>
                                    <p class="text-danger">Bu işlem geri alınamaz ve seansa ait tüm biletler silinecektir.</p>
                                </div>
                                <div class="modal-footer">
                                    <form method="POST">
                                        <input type="hidden" name="screening_id" value="<?php echo $screening['id']; ?>">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">İptal</button>
                                        <button type="submit" name="delete_screening" class="btn btn-danger">Sil</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 