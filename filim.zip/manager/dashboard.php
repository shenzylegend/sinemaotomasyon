<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is manager
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'manager') {
    header('Location: ../login.php');
    exit();
}

// Get manager information
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$manager = $stmt->fetch();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    
    // Update user profile
    $stmt = $db->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
    $stmt->execute([$name, $email, $_SESSION['user_id']]);
    
    $_SESSION['name'] = $name;
    $_SESSION['email'] = $email;
    
    header('Location: dashboard.php');
    exit();
}

// Get statistics
$stats = [
    'total_movies' => $db->query("SELECT COUNT(*) FROM movies")->fetchColumn(),
    'total_screenings' => $db->query("SELECT COUNT(*) FROM screenings WHERE screening_time > NOW()")->fetchColumn(),
    'total_tickets' => $db->query("SELECT COUNT(*) FROM tickets")->fetchColumn(),
    'total_revenue' => $db->query("SELECT COALESCE(SUM(total_price), 0) FROM tickets")->fetchColumn()
];

// Get recent tickets
$recentTickets = $db->query("
    SELECT t.*, m.title as movie_title, u.name as user_name, s.screening_time, h.name as hall_name
    FROM tickets t
    JOIN screenings s ON t.screening_id = s.id
    JOIN movies m ON s.movie_id = m.id
    JOIN users u ON t.user_id = u.id
    JOIN halls h ON s.hall_id = h.id
    ORDER BY t.created_at DESC
    LIMIT 5
")->fetchAll();

// Get upcoming screenings
$upcomingScreenings = $db->query("
    SELECT s.*, m.title as movie_title, h.name as hall_name,
           (SELECT COUNT(*) FROM tickets t WHERE t.screening_id = s.id) as sold_tickets,
           h.total_seats
    FROM screenings s
    JOIN movies m ON s.movie_id = m.id
    JOIN halls h ON s.hall_id = h.id
    WHERE s.screening_time > NOW()
    ORDER BY s.screening_time ASC
    LIMIT 5
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yönetici Paneli - Sinema Otomasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            color: #17a2b8;
        }
        .stat-card {
            transition: transform 0.2s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-3">
                <h3 class="text-center mb-4">Yönetici Paneli</h3>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="movies.php">
                            <i class="fas fa-film"></i> Filmler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="screenings.php">
                            <i class="fas fa-calendar-alt"></i> Seanslar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tickets.php">
                            <i class="fas fa-ticket-alt"></i> Biletler
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> Profilim
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <h2 class="mb-4">Hoş Geldiniz, <?php echo htmlspecialchars($manager['name']); ?></h2>
                <h2 class="mb-4">Mail adresiniz: <?php echo htmlspecialchars($manager['email']); ?></h2>

                <!-- Statistics -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card stat-card bg-primary text-white">
                            <div class="card-body">
                                <h5 class="card-title">Toplam Film</h5>
                                <h2 class="card-text"><?php echo $stats['total_movies']; ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body">
                                <h5 class="card-title">Aktif Seans</h5>
                                <h2 class="card-text"><?php echo $stats['total_screenings']; ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-info text-white">
                            <div class="card-body">
                                <h5 class="card-title">Satılan Bilet</h5>
                                <h2 class="card-text"><?php echo $stats['total_tickets']; ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-warning text-white">
                            <div class="card-body">
                                <h5 class="card-title">Toplam Gelir</h5>
                                <h2 class="card-text"><?php echo number_format($stats['total_revenue'], 2); ?> TL</h2>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Tickets -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-ticket-alt"></i> Son Satılan Biletler
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Bilet No</th>
                                        <th>Film</th>
                                        <th>Kullanıcı</th>
                                        <th>Seans</th>
                                        <th>Salon</th>
                                        <th>Fiyat</th>
                                        <th>Tarih</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentTickets as $ticket): ?>
                                    <tr>
                                        <td>#<?php echo $ticket['id']; ?></td>
                                        <td><?php echo htmlspecialchars($ticket['movie_title']); ?></td>
                                        <td><?php echo htmlspecialchars($ticket['user_name']); ?></td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($ticket['screening_time'])); ?></td>
                                        <td><?php echo htmlspecialchars($ticket['hall_name']); ?></td>
                                        <td><?php echo number_format($ticket['total_price'], 2); ?> TL</td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($ticket['created_at'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Upcoming Screenings -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-calendar-alt"></i> Yaklaşan Seanslar
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Film</th>
                                        <th>Salon</th>
                                        <th>Tarih</th>
                                        <th>Doluluk</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($upcomingScreenings as $screening): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($screening['movie_title']); ?></td>
                                        <td><?php echo htmlspecialchars($screening['hall_name']); ?></td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($screening['screening_time'])); ?></td>
                                        <td>
                                            <div class="progress">
                                                <?php 
                                                $percentage = ($screening['sold_tickets'] / $screening['total_seats']) * 100;
                                                $color = $percentage > 80 ? 'danger' : ($percentage > 50 ? 'warning' : 'success');
                                                ?>
                                                <div class="progress-bar bg-<?php echo $color; ?>" 
                                                     role="progressbar" 
                                                     style="width: <?php echo $percentage; ?>%">
                                                    <?php echo $screening['sold_tickets']; ?>/<?php echo $screening['total_seats']; ?>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 